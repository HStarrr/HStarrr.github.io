"""

# 暴力破解第二段字符
import hashlib
import itertools

for i in range(28,33):
    for i in itertools.product('12',repeat=i):
        data = bytes("".join(i),'utf8')
        md5str = hashlib.md5(data).hexdigest()
        # 1221222221212121211122112111
        if md5str == '39c1ca4b6d64c40558425432c11624a8':
            print('it\'s find!')
            print('str:%s, md5str:%s'%(data, md5str))
            exit()
"""   
         
"""
# 获取第一段字符
a = 'F4 F3 D2 EE 8B A1 77 99'.split(' ')
b = 'A6 91 E4 D9 EC F6 F6 1A'.split(' ')

for i in range(0,8):
    # print(a[i])
    i1 = int(a[i],16)
    i2 = int(b[i],16)
    print(chr(i1^i2^i),end='')
"""

"""
# 获取第二段字符
a = '66 02 55'.split(' ')
b = '32 41 13'.split(' ')

for i in range(0,3):
    # print(a[i])
    i1 = int(a[i],16)
    i2 = int(b[i],16)
    print(chr(i1^i2),end='')
"""
    

"""
# 分析结果
1234567890abcdef#1234567890abcdef##

12345 1                    = 6
1234567 2                  = 9
1234567890 3               = 13
1234567890abcd 5           = 19
1234567890abcdefghij 8     = 28
29**a 13				   = 42

67890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef###

#123456789#0abcdefghijklmnopqrstuvwzyx0#

123456789#0abcdefghijklmnopqrstuvwzyx0##

123456789#1212121212121212121212121212##




123456789#1221222221212121211122112111##

abcdef#1221222221212121211122112111#123#

abcde#1221222221212121211122112111#123#



Rc44cR#1221222221212121211122112111#123#

Rc44cR#1221222221212121211122112111#TCF#


第一段正确比较答案：
F4 F3 D2 EE 8B A1 77 99
Rc44cR

顺序：
RAX: A0 AC 78 D8 61 B7 B7 FD EB
RCX: A6 91 E4 D9 EC F6 F6 1A 67

第二段正确答案：比较md5
    正确比较答案：39c1ca4b6d64c40558425432c11624a8
1221222221212121211122112111

第三段正确比较答案：
66 02 55
TCF

顺序：
RAX: A3 14 E4
RCX: 32 41 13


最终结果：
Rc44cR#1221222221212121211122112111#TCF#
Rc44c#1221222221212121211122112111#TCF#

flag{sha224('Rc44cR#1221222221212121211122112111#TCF#')[0:32]}
flag{sha224('Rc44c#1221222221212121211122112111#TCF#')[0:32]}

flag{7929ea6ed68b36d739d3a80b5269c077}
flag{3f176e7139e019530633215abc6732ff}
"""